import { createServerSupabaseClient } from "@/lib/supabase/server";
import type { AdminSnapshot } from "@/lib/supabase/types";

async function count(table: string, filters?: (q: any) => any) {
  const supabase = await createServerSupabaseClient();
  let query: any = supabase.from(table).select("*", { count: "exact", head: true });
  if (filters) query = filters(query);
  const { count, error } = await query;
  if (error) return null;
  return count ?? 0;
}

export async function getAdminSnapshot(): Promise<AdminSnapshot> {
  const [products, orders, briefs, activeProjects, members] = await Promise.all([
    count("products"), count("orders"), count("project_briefs"),
    count("client_projects", q => q.not("status", "in", "(complete,on_hold)")),
    count("memberships", q => q.eq("status", "active")),
  ]);
  return { products, orders, briefs, activeProjects, members, source: "supabase" };
}

"use client";

import { useActionState } from "react";
import { signInAction } from "@/app/auth/actions";

export default function SignInForm({ next = "/portal", configured }: { next?: string; configured: boolean }) {
  const [state, action, pending] = useActionState(signInAction, {});
  return <form className="auth-form" action={action}>
    <small>{configured ? "SECURE CLIENT / MEMBER ACCESS" : "AUTHENTICATION FOUNDATION"}</small>
    <h2>Sign in.</h2>
    <input type="hidden" name="next" value={next}/>
    <label>Email address<input type="email" name="email" autoComplete="email" placeholder="you@company.com" required disabled={!configured}/></label>
    <label>Password<input type="password" name="password" autoComplete="current-password" placeholder="••••••••" required disabled={!configured}/></label>
    <button disabled={!configured || pending}>{pending ? "SIGNING IN…" : "SIGN IN →"}</button>
    {state?.error && <p className="auth-error" role="alert">{state.error}</p>}
    {!configured && <p>Sign-in is ready in code but remains disabled until a Supabase project is connected and its public credentials are configured.</p>}
  </form>;
}

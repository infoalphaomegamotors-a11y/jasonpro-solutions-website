"use client";

import { useState } from "react";
import type { AdminSnapshot, Profile } from "@/lib/supabase/types";
import { signOutAction } from "@/app/auth/actions";

const sections = ["overview","products","orders","projects","members","content","audit"] as const;
type Section = (typeof sections)[number];

const readiness = [
  ["Database schema", "READY"],
  ["Row-Level Security", "READY"],
  ["Auth model", "READY FOR CONFIG"],
  ["Project storage", "READY FOR CONFIG"],
  ["Payments", "PROVIDER NOT SELECTED"],
] as const;

export function AdminDashboard({ snapshot, profile, configured }: { snapshot: AdminSnapshot; profile?: Profile | null; configured: boolean }) {
  const [section, setSection] = useState<Section>("overview");

  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <div className="admin-brand"><span>JP</span><div><b>JASONPRO</b><small>CONTROL SYSTEM</small></div></div>
        <nav>{sections.map((item, index) => <button key={item} className={section === item ? "active" : ""} onClick={() => setSection(item)}><span>{String(index + 1).padStart(2,"0")}</span>{item.toUpperCase()}</button>)}</nav>
        <div className="admin-env"><i/><span>{configured ? "SUPABASE CONNECTED" : "BACKEND FOUNDATION"}</span><small>{configured ? "Live protected data is available according to role permissions." : "Supabase connection not configured in this source build."}</small></div>
      </aside>

      <section className="admin-main">
        <header className="admin-topbar"><div><small>ADMIN / {section.toUpperCase()}</small><h1>{section === "overview" ? "Operating overview." : section.charAt(0).toUpperCase() + section.slice(1)}</h1></div><div className="admin-user"><span>{profile?.role?.toUpperCase() || "ADMIN ACCESS"}</span><b>{profile?.email || (configured ? "AUTHENTICATED" : "AUTH REQUIRED IN PRODUCTION")}</b>{configured && <form action={signOutAction}><button>SIGN OUT</button></form>}</div></header>

        {section === "overview" ? <>
          <div className="admin-metrics">
            {[["Products", snapshot.products],["Orders", snapshot.orders],["Project briefs", snapshot.briefs],["Active projects", snapshot.activeProjects],["Members", snapshot.members]].map(([label,value]) => <article key={String(label)}><small>{label}</small><strong>{value ?? "—"}</strong><span>{snapshot.source === "supabase" ? "LIVE PROTECTED DATA" : "LIVE DATA AFTER SUPABASE CONNECTION"}</span></article>)}
          </div>
          <div className="admin-grid">
            <article className="admin-panel admin-readiness"><span>PLATFORM READINESS</span><h2>{configured ? "Backend architecture is connected and governed by authenticated RLS access." : "Backend architecture is defined before credentials are connected."}</h2><div>{readiness.map(([label,status]) => <p key={label}><b>{label}</b><small className={status === "READY" ? "ready" : ""}>{status}</small></p>)}</div></article>
            <article className="admin-panel"><span>ACCESS MODEL</span><h2>Least privilege by default.</h2><p>Customer, Member, Client, Content Manager and Admin roles are represented in the database. Sensitive project, invoice and membership records are protected by RLS policies.</p><div className="admin-role-rail"><i>CUSTOMER</i><i>MEMBER</i><i>CLIENT</i><i>MANAGER</i><i>ADMIN</i></div></article>
          </div>
        </> : <div className="admin-module"><span>{section.toUpperCase()} MODULE</span><h2>Production data surface prepared.</h2><p>{configured ? "This module is connected to the protected backend. Record-level management screens remain the next implementation step." : "This screen is intentionally not populated with invented business records. Once Supabase is connected, this module will read authorised rows from the corresponding protected tables."}</p><div className="admin-table-head"><b>RECORD</b><b>STATUS</b><b>UPDATED</b><b>ACTION</b></div><div className="admin-empty"><strong>{configured ? "MODULE CONNECTED" : "NO CONNECTED DATA"}</strong><span>{configured ? "Detailed record management will be wired into this surface next." : "Configure Supabase and authentication to activate this module."}</span></div></div>}
      </section>
    </div>
  );
}

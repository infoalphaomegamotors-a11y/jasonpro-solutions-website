import { AdminDashboard } from "@/components/admin/AdminDashboard";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { requireRole } from "@/lib/auth/session";
import { getAdminSnapshot } from "@/lib/data/admin";
import { unconfiguredAdminSnapshot } from "@/lib/supabase/adminSnapshot";

export const metadata = { title: "Admin — JasonPro Solutions" };

export default async function AdminPage() {
  if (!isSupabaseConfigured) return <main className="admin-page"><AdminDashboard snapshot={unconfiguredAdminSnapshot} profile={null} configured={false}/></main>;
  const profile = await requireRole(["admin", "content_manager"], "/admin");
  if (!profile) return null;
  const snapshot = await getAdminSnapshot();
  return <main className="admin-page"><AdminDashboard snapshot={snapshot} profile={profile} configured/></main>;
}

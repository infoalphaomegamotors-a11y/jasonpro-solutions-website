"use server";

import { redirect } from "next/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/config";

export type AuthState = { error?: string };

export async function signInAction(_state: AuthState, formData: FormData): Promise<AuthState> {
  if (!isSupabaseConfigured) return { error: "Authentication is not connected yet." };
  const email = String(formData.get("email") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  const next = String(formData.get("next") ?? "/portal");
  if (!email || !password) return { error: "Enter your email address and password." };

  const supabase = await createServerSupabaseClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { error: "Sign-in failed. Check your credentials and try again." };
  redirect(next.startsWith("/") ? next : "/portal");
  return {};
}

export async function signOutAction() {
  if (isSupabaseConfigured) {
    const supabase = await createServerSupabaseClient();
    await supabase.auth.signOut();
  }
  redirect("/");
}

export type SignUpState = { error?: string; success?: string };

export async function signUpAction(_state: SignUpState, formData: FormData): Promise<SignUpState> {
  if (!isSupabaseConfigured) return { error: "Account creation is not connected yet." };
  const fullName = String(formData.get("full_name") ?? "").trim().slice(0, 160);
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  if (fullName.length < 2 || !email.includes("@") || password.length < 8) {
    return { error: "Enter your name, a valid email address and a password of at least 8 characters." };
  }

  const supabase = await createServerSupabaseClient();
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName },
      emailRedirectTo: `${siteUrl.replace(/\/$/, "")}/auth/callback?next=/portal`,
    },
  });

  if (error) return { error: error.message || "Account creation failed. Please try again." };
  if (data.session) redirect("/portal");
  return { success: "Account created. Check your email and confirm your address before signing in." };
}

import Link from "next/link";
import InteriorHeader from "@/components/InteriorHeader";

const services=[
  ["01","WEB DESIGN & DEVELOPMENT","Premium websites, product interfaces and web applications engineered around trust, speed and conversion.","Websites · Web apps · UX/UI · Performance"],
  ["02","BUSINESS SYSTEMS & SAAS","Operational systems, portals and SaaS products that reduce manual work and create scalable workflows.","Dashboards · Portals · SaaS · Automation"],
  ["03","GRAPHIC DESIGN & BRAND IDENTITY","Distinct brand systems designed to make businesses recognisable, consistent and commercially credible.","Identity · Campaigns · Marketing collateral"],
  ["04","AI, AUTOMATION & INTELLIGENCE","Practical AI and automation applied to repetitive workflows, customer journeys and decision support.","Automation · AI workflows · Assistants"],
  ["05","BUSINESS INTELLIGENCE & DATA","Dashboards and information systems that turn operational data into clearer business decisions.","Analytics · Reporting · Decision systems"],
  ["06","COMMERCE & DIGITAL PRODUCTS","Online stores, memberships, subscriptions and digital-product experiences designed to sell and scale.","E-commerce · Memberships · Digital goods"],
];
export default function ServicesPage(){return <main className="interior-page"><InteriorHeader/><section className="interior-hero"><span>CAPABILITIES / 06</span><h1>WE DON&apos;T SELL<br/>DECORATION.<br/><em>WE BUILD LEVERAGE.</em></h1><p>Design, technology and business thinking combined into complete commercial solutions.</p></section><section className="service-list-page">{services.map(([id,title,copy,meta])=><article key={id}><span>{id}</span><div><h2>{title}</h2><p>{copy}</p><small>{meta}</small></div><Link href="/contact">DISCUSS THIS →</Link></article>)}</section><section className="interior-end"><small>NOT SURE WHAT YOU NEED?</small><h2>START WITH THE BUSINESS PROBLEM.</h2><Link href="/contact">START A PROJECT →</Link></section></main>}
